package calculator

import spock.lang.Specification

class ErrorSpec extends Specification {

    void "Test dividing two numbers is correct"() {
        when:
        Integer sum = MyCalculator.div(8, 4)

        then:
        sum == 2
    }


}
