package calculator

import spock.lang.Specification

class MyCalculatorSpec extends Specification {

    void "Test multiply two numbers"() {
        when:
        Integer sum = MyCalculator.mul(10, 6)

        then:
            sum == 60
    }

    void "Test multiply by zero"() {
        when:
        Integer sum = MyCalculator.mul(0, 6)

        then:
        sum == 0
    }


    void "Test divide two numbers"() {
        when:
        Integer sum = MyCalculator.div(1, 1)

        then:
        sum == 1
    }

    void "Test add two numbers"() {
        when:
        Integer sum = MyCalculator.add(7, 8)

        then:
        sum == 15
    }

    void "Test subtracting two numbers"() {
        when:
        Integer sum = MyCalculator.sub(10, 6)

        then:
        sum == 4
    }

}
