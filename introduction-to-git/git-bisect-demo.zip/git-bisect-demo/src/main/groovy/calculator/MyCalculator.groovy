package calculator

/**
 * A simple class implementing the four basic arithmetic methods: +,-,/,*
 */
class MyCalculator {

    static Integer mul(Integer a, Integer b) {
        return a * b
    }

    static Integer div(Integer a, Integer b) {
        a / b * a
    }

    static Integer add(Integer a, Integer b) {
        return a + b
    }

    static Integer sub(Integer a, Integer b) {
        return a - b
    }

}
