#!/usr/bin/env bash

# HEAD is bad, origin is good
git bisect start HEAD e4e704d307ea2524b175945d29e9e34f0de389f2 --
git bisect run ./gradlew check