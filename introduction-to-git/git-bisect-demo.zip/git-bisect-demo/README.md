# Git bisect demo

A simple example written in [Groovy](http://groovy-lang.org/) and tested using the [Spock](https://spockframework.org/)
framework for demonstrating `git bisect`.

## Description

A simple calculator implementing addition, subtraction, multiplikation and division. \
The project contains an error, introduced in some previous commit, we use `git bisect` to find the bug, and when it
was introduced.

To run the `git bisect` example:
```
#!/usr/bin/env bash

# HEAD is bad, origin is good
git bisect start HEAD e4e704d307ea2524b175945d29e9e34f0de389f2 --
git bisect run ./gradlew check
```

